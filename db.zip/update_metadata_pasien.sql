-- =====================================================================
-- Pembaruan: metadata pasien (nama ibu kandung, alamat terstruktur, pekerjaan terstandar)
-- Jalankan HANYA jika database.sql versi lama sudah diimpor dan Anda tidak ingin
-- mengimpor ulang (data pasien/kunjungan tetap aman).
-- Jika belum punya data apa pun, cukup impor ulang database.sql terbaru.
--
-- Urutan: (1) jalankan file ini, (2) impor wilayah.sql.
-- Catatan: pasien lama akan memiliki Nama Ibu Kandung kosong dan wilayah kosong.
-- Formulir akan mewajibkan keduanya saat data pasien tersebut diubah/dilengkapi.
-- =====================================================================
USE rme_belajar;

CREATE TABLE ref_pekerjaan (
  kode CHAR(2) NOT NULL PRIMARY KEY,
  nama VARCHAR(60) NOT NULL
) ENGINE=InnoDB;

INSERT INTO ref_pekerjaan (kode, nama) VALUES
('01','Tidak / belum bekerja'),
('02','Pelajar / mahasiswa'),
('03','Ibu rumah tangga'),
('04','PNS / ASN'),
('05','TNI / Polri'),
('06','Pegawai BUMN / BUMD'),
('07','Pegawai swasta'),
('08','Wiraswasta / pedagang'),
('09','Petani / pekebun / peternak'),
('10','Nelayan'),
('11','Buruh / pekerja harian'),
('12','Tenaga kesehatan'),
('13','Guru / dosen'),
('14','Pensiunan'),
('15','Pekerjaan lainnya');

ALTER TABLE pasien
  ADD COLUMN nama_ibu_kandung VARCHAR(120) NOT NULL DEFAULT '' AFTER nama,
  ADD COLUMN kode_provinsi VARCHAR(2) NULL AFTER alamat,
  ADD COLUMN kode_kabkota VARCHAR(5) NULL AFTER kode_provinsi,
  ADD COLUMN kode_kecamatan VARCHAR(8) NULL AFTER kode_kabkota,
  ADD COLUMN kode_kelurahan VARCHAR(13) NULL AFTER kode_kecamatan,
  ADD COLUMN pekerjaan_kode CHAR(2) NULL AFTER gol_darah,
  ADD INDEX idx_pasien_dup (nama, tgl_lahir);

-- Petakan teks pekerjaan lama ke kode baru (yang tidak cocok masuk "Pekerjaan lainnya")
UPDATE pasien SET pekerjaan_kode = CASE
  WHEN LOWER(pekerjaan) REGEXP 'ibu rumah|irt'                       THEN '03'
  WHEN LOWER(pekerjaan) REGEXP 'pelajar|mahasiswa|siswa'             THEN '02'
  WHEN LOWER(pekerjaan) REGEXP 'belum|tidak bekerja|menganggur'      THEN '01'
  WHEN LOWER(pekerjaan) REGEXP 'guru|dosen'                          THEN '13'
  WHEN LOWER(pekerjaan) REGEXP 'perawat|bidan|dokter|apoteker'       THEN '12'
  WHEN LOWER(pekerjaan) REGEXP 'pns|asn|pegawai negeri'              THEN '04'
  WHEN LOWER(pekerjaan) REGEXP 'tni|polri|polisi'                    THEN '05'
  WHEN LOWER(pekerjaan) REGEXP 'bumn|bumd'                           THEN '06'
  WHEN LOWER(pekerjaan) REGEXP 'swasta|karyawan'                     THEN '07'
  WHEN LOWER(pekerjaan) REGEXP 'wiraswasta|pedagang|wirausaha|usaha' THEN '08'
  WHEN LOWER(pekerjaan) REGEXP 'petani|pekebun|peternak'             THEN '09'
  WHEN LOWER(pekerjaan) REGEXP 'nelayan'                             THEN '10'
  WHEN LOWER(pekerjaan) REGEXP 'buruh|kuli'                          THEN '11'
  WHEN LOWER(pekerjaan) REGEXP 'pensiun'                             THEN '14'
  ELSE '15' END
WHERE pekerjaan IS NOT NULL AND pekerjaan <> '';

ALTER TABLE pasien
  ADD CONSTRAINT fk_pasien_pekerjaan FOREIGN KEY (pekerjaan_kode) REFERENCES ref_pekerjaan(kode),
  DROP COLUMN pekerjaan;
