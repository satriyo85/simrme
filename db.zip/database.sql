-- =====================================================================
-- SIMRME BELAJAR - Skema Database & Data Awal
-- Sistem Rekam Medis Elektronik sederhana untuk pembelajaran (D4 MIK)
-- Semua data pasien di bawah ini FIKTIF.
-- Cara pakai: import file ini via phpMyAdmin atau:
--   mysql -u root -p < database.sql
-- Setelah itu impor juga wilayah.sql (data Kode Wilayah untuk alamat terstruktur).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS rme_belajar
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rme_belajar;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS audit_log, jadwal_dokter, resep_detail, resep, pemeriksaan_diagnosa, pemeriksaan,
  triage, kunjungan, pasien, ref_pekerjaan, obat, icd10, poli, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- Pengguna & peran
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nama VARCHAR(100) NOT NULL,
  role ENUM('admin','pendaftaran','perawat','dokter','apoteker') NOT NULL,
  spesialisasi VARCHAR(80) NULL,            -- khusus dokter, mis. 'Spesialis Anak (Sp.A)'
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Master: poli, ICD-10, obat
-- ---------------------------------------------------------------------
CREATE TABLE poli (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(5) NOT NULL UNIQUE,
  nama VARCHAR(80) NOT NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE icd10 (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(10) NOT NULL UNIQUE,
  nama VARCHAR(200) NOT NULL,
  INDEX idx_icd_nama (nama)
) ENGINE=InnoDB;

CREATE TABLE obat (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(120) NOT NULL,
  satuan VARCHAR(20) NOT NULL,
  stok INT NOT NULL DEFAULT 0,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  INDEX idx_obat_nama (nama)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- Jadwal praktik dokter per poli
-- hari: 1=Senin ... 7=Minggu
-- ---------------------------------------------------------------------
CREATE TABLE jadwal_dokter (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  dokter_id INT UNSIGNED NOT NULL,
  poli_id INT UNSIGNED NOT NULL,
  hari TINYINT UNSIGNED NOT NULL,
  jam_mulai TIME NOT NULL,
  jam_selesai TIME NOT NULL,
  kuota SMALLINT UNSIGNED NOT NULL DEFAULT 20,
  menit_per_pasien SMALLINT UNSIGNED NOT NULL DEFAULT 15,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (dokter_id) REFERENCES users(id),
  FOREIGN KEY (poli_id) REFERENCES poli(id),
  UNIQUE KEY uq_jadwal (dokter_id, poli_id, hari, jam_mulai),
  INDEX idx_jadwal_hari (hari, poli_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Pasien
-- ---------------------------------------------------------------------
-- Referensi pekerjaan (value set makro, dipakai untuk dropdown dan pelaporan)
CREATE TABLE ref_pekerjaan (
  kode CHAR(2) NOT NULL PRIMARY KEY,
  nama VARCHAR(60) NOT NULL
) ENGINE=InnoDB;

INSERT INTO ref_pekerjaan (kode, nama) VALUES
('01','Tidak / belum bekerja'),
('02','Pelajar / mahasiswa'),
('03','Ibu rumah tangga'),
('04','PNS / ASN'),
('05','TNI / Polri'),
('06','Pegawai BUMN / BUMD'),
('07','Pegawai swasta'),
('08','Wiraswasta / pedagang'),
('09','Petani / pekebun / peternak'),
('10','Nelayan'),
('11','Buruh / pekerja harian'),
('12','Tenaga kesehatan'),
('13','Guru / dosen'),
('14','Pensiunan'),
('15','Pekerjaan lainnya');

-- Metadata pasien: identitas lengkap + alamat terstruktur (Kode Wilayah Kemendagri)
CREATE TABLE pasien (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  no_rm VARCHAR(15) NOT NULL UNIQUE,
  nik CHAR(16) NULL UNIQUE,
  no_bpjs VARCHAR(20) NULL,
  nama VARCHAR(120) NOT NULL,
  nama_ibu_kandung VARCHAR(120) NOT NULL DEFAULT '',   -- wajib diisi pada form (validasi berlapis / cegah data ganda)
  jk ENUM('L','P') NOT NULL,
  tempat_lahir VARCHAR(60) NULL,
  tgl_lahir DATE NOT NULL,
  alamat TEXT NULL,                                    -- alamat jalan / RT / RW
  kode_provinsi VARCHAR(2) NULL,                       -- mis. 35
  kode_kabkota VARCHAR(5) NULL,                        -- mis. 35.01
  kode_kecamatan VARCHAR(8) NULL,                      -- mis. 35.01.01
  kode_kelurahan VARCHAR(13) NULL,                     -- mis. 35.01.01.2001
  telepon VARCHAR(20) NULL,
  gol_darah ENUM('A','B','AB','O','-') NOT NULL DEFAULT '-',
  pekerjaan_kode CHAR(2) NULL,
  alergi VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pasien_nama (nama),
  INDEX idx_pasien_dup (nama, tgl_lahir),
  FOREIGN KEY (pekerjaan_kode) REFERENCES ref_pekerjaan(kode)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Kunjungan (episode pelayanan)
-- status: menunggu -> siap_periksa -> farmasi -> selesai (atau batal)
-- ---------------------------------------------------------------------
CREATE TABLE kunjungan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  no_kunjungan VARCHAR(20) NOT NULL UNIQUE,
  pasien_id INT UNSIGNED NOT NULL,
  poli_id INT UNSIGNED NOT NULL,
  tgl_kunjungan DATE NOT NULL,
  no_antrian VARCHAR(10) NOT NULL,
  dokter_id INT UNSIGNED NULL,
  estimasi_jam TIME NULL,
  jenis_bayar ENUM('UMUM','BPJS') NOT NULL DEFAULT 'UMUM',
  keluhan_awal VARCHAR(255) NULL,
  status ENUM('menunggu','siap_periksa','farmasi','selesai','batal') NOT NULL DEFAULT 'menunggu',
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (pasien_id) REFERENCES pasien(id),
  FOREIGN KEY (poli_id) REFERENCES poli(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  FOREIGN KEY (dokter_id) REFERENCES users(id),
  INDEX idx_kunj_dokter (dokter_id, tgl_kunjungan),
  INDEX idx_kunj_tgl (tgl_kunjungan, status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Triage / pengkajian awal perawat (tanda vital)
-- ---------------------------------------------------------------------
CREATE TABLE triage (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kunjungan_id INT UNSIGNED NOT NULL UNIQUE,
  td_sistol SMALLINT NULL,
  td_diastol SMALLINT NULL,
  nadi SMALLINT NULL,
  suhu DECIMAL(4,1) NULL,
  rr SMALLINT NULL,
  spo2 SMALLINT NULL,
  bb DECIMAL(5,1) NULL,
  tb DECIMAL(5,1) NULL,
  keluhan_utama TEXT NULL,
  perawat_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (kunjungan_id) REFERENCES kunjungan(id) ON DELETE CASCADE,
  FOREIGN KEY (perawat_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Pemeriksaan dokter (SOAP) + diagnosa ICD-10
-- ---------------------------------------------------------------------
CREATE TABLE pemeriksaan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kunjungan_id INT UNSIGNED NOT NULL UNIQUE,
  subjektif TEXT NULL,
  objektif TEXT NULL,
  assessment TEXT NULL,
  plan TEXT NULL,
  dokter_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (kunjungan_id) REFERENCES kunjungan(id) ON DELETE CASCADE,
  FOREIGN KEY (dokter_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE pemeriksaan_diagnosa (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pemeriksaan_id INT UNSIGNED NOT NULL,
  icd_id INT UNSIGNED NOT NULL,
  jenis ENUM('utama','sekunder') NOT NULL DEFAULT 'sekunder',
  FOREIGN KEY (pemeriksaan_id) REFERENCES pemeriksaan(id) ON DELETE CASCADE,
  FOREIGN KEY (icd_id) REFERENCES icd10(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Resep & farmasi
-- ---------------------------------------------------------------------
CREATE TABLE resep (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kunjungan_id INT UNSIGNED NOT NULL UNIQUE,
  dokter_id INT UNSIGNED NOT NULL,
  status ENUM('menunggu','diserahkan') NOT NULL DEFAULT 'menunggu',
  apoteker_id INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  diserahkan_at DATETIME NULL,
  FOREIGN KEY (kunjungan_id) REFERENCES kunjungan(id) ON DELETE CASCADE,
  FOREIGN KEY (dokter_id) REFERENCES users(id),
  FOREIGN KEY (apoteker_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE resep_detail (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  resep_id INT UNSIGNED NOT NULL,
  obat_id INT UNSIGNED NOT NULL,
  jumlah INT UNSIGNED NOT NULL,
  aturan_pakai VARCHAR(100) NOT NULL,
  FOREIGN KEY (resep_id) REFERENCES resep(id) ON DELETE CASCADE,
  FOREIGN KEY (obat_id) REFERENCES obat(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Jejak audit (siapa melakukan apa, kapan)
-- ---------------------------------------------------------------------
CREATE TABLE audit_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  username VARCHAR(50) NULL,
  aksi VARCHAR(40) NOT NULL,
  keterangan VARCHAR(255) NULL,
  ip VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_waktu (created_at)
) ENGINE=InnoDB;

-- =====================================================================
-- DATA AWAL
-- Semua akun berkata sandi: password123  (WAJIB diganti di produksi/kelas)
-- =====================================================================
INSERT INTO users (username, password, nama, role, spesialisasi) VALUES
('admin',       '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'Administrator Sistem',        'admin',       NULL),
('pendaftaran', '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'Petugas Pendaftaran',        'pendaftaran', NULL),
('perawat',     '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'Ns. Perawat Triage',         'perawat',     NULL),
('dokter',      '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'dr. Andi Pratama',           'dokter',      'Dokter Umum'),
('dokter.anak', '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'dr. Bunga Lestari, Sp.A',    'dokter',      'Spesialis Anak (Sp.A)'),
('dokter.obgyn','$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'dr. Citra Maharani, Sp.OG',  'dokter',      'Spesialis Obstetri dan Ginekologi (Sp.OG)'),
('dokter.pd',   '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'dr. Dimas Wicaksono, Sp.PD', 'dokter',      'Spesialis Penyakit Dalam (Sp.PD)'),
('dokter.gigi', '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'drg. Eka Putri',             'dokter',      'Dokter Gigi'),
('apoteker',    '$2y$10$L6rznlbwo0c47tmuwkXrw.tUT4oNt4jEMrld.Mile.cadDcW72H6.', 'Apt. Petugas Farmasi',       'apoteker',    NULL);

INSERT INTO poli (kode, nama) VALUES
('UM','Poli Umum'),
('KI','Poli KIA / KB'),
('GI','Poli Gigi dan Mulut'),
('LN','Poli Lansia'),
('AN','Poli Anak');

-- Jadwal praktik (id dokter: 4 umum, 5 anak, 6 obgyn, 7 penyakit dalam, 8 gigi | id poli: 1 UM, 2 KI, 3 GI, 4 LN, 5 AN)
-- Setiap hari Senin-Sabtu tersedia minimal satu dokter agar mudah dipakai praktik di kelas.
INSERT INTO jadwal_dokter (dokter_id, poli_id, hari, jam_mulai, jam_selesai, kuota, menit_per_pasien) VALUES
(4,1,1,'08:00','14:00',30,10),(4,1,2,'08:00','14:00',30,10),(4,1,3,'08:00','14:00',30,10),
(4,1,4,'08:00','14:00',30,10),(4,1,5,'08:00','11:00',15,10),(4,1,6,'08:00','12:00',20,10),
(5,5,2,'09:00','13:00',16,15),(5,5,4,'09:00','13:00',16,15),(5,5,6,'09:00','12:00',12,15),
(6,2,1,'08:00','12:00',16,15),(6,2,3,'08:00','12:00',16,15),(6,2,5,'08:00','11:00',12,15),
(7,4,1,'09:00','13:00',16,15),(7,4,2,'09:00','13:00',16,15),(7,4,3,'09:00','13:00',16,15),(7,4,4,'09:00','13:00',16,15),
(8,3,1,'08:00','13:00',20,15),(8,3,2,'08:00','13:00',20,15),(8,3,3,'08:00','13:00',20,15),
(8,3,4,'08:00','13:00',20,15),(8,3,5,'08:00','11:00',12,15);

INSERT INTO icd10 (kode, nama) VALUES
('A01.0','Demam tifoid'),
('A09','Diare dan gastroenteritis, diduga infeksi'),
('A91','Demam berdarah dengue'),
('B34.9','Infeksi virus, tidak spesifik'),
('B35.4','Tinea korporis'),
('D64.9','Anemia, tidak spesifik'),
('E11.9','Diabetes melitus tipe 2 tanpa komplikasi'),
('E66.9','Obesitas, tidak spesifik'),
('E78.5','Hiperlipidemia, tidak spesifik'),
('G43.9','Migrain, tidak spesifik'),
('H10.9','Konjungtivitis, tidak spesifik'),
('H66.9','Otitis media, tidak spesifik'),
('I10','Hipertensi esensial (primer)'),
('J00','Nasofaringitis akut (common cold)'),
('J02.9','Faringitis akut, tidak spesifik'),
('J03.9','Tonsilitis akut, tidak spesifik'),
('J06.9','Infeksi saluran napas atas akut (ISPA), tidak spesifik'),
('J11.1','Influenza dengan manifestasi pernapasan lain'),
('J18.9','Pneumonia, tidak spesifik'),
('J20.9','Bronkitis akut, tidak spesifik'),
('J30.4','Rinitis alergi, tidak spesifik'),
('J45.9','Asma, tidak spesifik'),
('K02.9','Karies gigi, tidak spesifik'),
('K04.0','Pulpitis'),
('K05.1','Gingivitis kronis'),
('K21.9','Penyakit refluks gastroesofageal tanpa esofagitis'),
('K29.7','Gastritis, tidak spesifik'),
('K30','Dispepsia'),
('L03.9','Selulitis, tidak spesifik'),
('L08.9','Infeksi lokal kulit dan jaringan subkutan'),
('L20.9','Dermatitis atopik, tidak spesifik'),
('L30.9','Dermatitis, tidak spesifik'),
('M10.9','Gout (asam urat), tidak spesifik'),
('M19.9','Osteoartritis, tidak spesifik'),
('M54.5','Nyeri punggung bawah'),
('M79.1','Mialgia'),
('N39.0','Infeksi saluran kemih, lokasi tidak spesifik'),
('O21.0','Hiperemesis gravidarum ringan'),
('R05','Batuk'),
('R10.4','Nyeri perut lainnya dan tidak spesifik'),
('R50.9','Demam, tidak spesifik'),
('R51','Nyeri kepala'),
('S61.9','Luka terbuka pergelangan tangan dan tangan, bagian tidak spesifik'),
('T78.4','Alergi, tidak spesifik'),
('Z00.0','Pemeriksaan kesehatan umum'),
('Z23','Kebutuhan imunisasi terhadap penyakit bakteri tunggal'),
('Z34.9','Pengawasan kehamilan normal, tidak spesifik');

INSERT INTO obat (kode, nama, satuan, stok) VALUES
('OB001','Paracetamol 500 mg','tablet',500),
('OB002','Ibuprofen 400 mg','tablet',300),
('OB003','Natrium diklofenak 50 mg','tablet',200),
('OB004','Amoxicillin 500 mg','kapsul',400),
('OB005','Cefadroxil 500 mg','kapsul',200),
('OB006','Kotrimoksazol 480 mg','tablet',250),
('OB007','Ciprofloxacin 500 mg','tablet',150),
('OB008','Metronidazole 500 mg','tablet',150),
('OB009','Amlodipine 5 mg','tablet',300),
('OB010','Captopril 25 mg','tablet',300),
('OB011','Metformin 500 mg','tablet',400),
('OB012','Glibenklamid 5 mg','tablet',200),
('OB013','Simvastatin 10 mg','tablet',200),
('OB014','Allopurinol 100 mg','tablet',200),
('OB015','Antasida DOEN','tablet',500),
('OB016','Omeprazole 20 mg','kapsul',250),
('OB017','Salbutamol 2 mg','tablet',200),
('OB018','Chlorpheniramine maleat (CTM) 4 mg','tablet',500),
('OB019','Cetirizine 10 mg','tablet',200),
('OB020','Ambroxol 30 mg','tablet',250),
('OB021','Glyceryl guaiacolate (GG) 100 mg','tablet',250),
('OB022','Dexamethasone 0,5 mg','tablet',200),
('OB023','Vitamin B kompleks','tablet',500),
('OB024','Vitamin C 50 mg','tablet',500),
('OB025','Asam folat 400 mcg','tablet',300),
('OB026','Tablet tambah darah (Fe + asam folat)','tablet',400),
('OB027','Oralit','sachet',200),
('OB028','Zinc 20 mg','tablet',200),
('OB029','Hidrokortison krim 2,5%','tube',60),
('OB030','Ketokonazol krim 2%','tube',60),
('OB031','Kloramfenikol salep mata 1%','tube',40);

INSERT INTO pasien (no_rm, nik, no_bpjs, nama, nama_ibu_kandung, jk, tempat_lahir, tgl_lahir, alamat,
                    kode_provinsi, kode_kabkota, kode_kecamatan, kode_kelurahan, telepon, gol_darah, pekerjaan_kode, alergi) VALUES
('RM-000001','3501010101900001','0001234567890','Budi Santoso','Sri Wahyuni','L','Pacitan','1990-01-01','Jl. Mawar No. 12, RT 02 / RW 01','35','35.01','35.01.01','35.01.01.2001','081200000001','O','09',NULL),
('RM-000002','3501014502850002',NULL,'Siti Aminah','Sumirah','P','Ponorogo','1985-02-05','Dsn. Krajan, RT 02 / RW 01','35','35.02','35.02.01','35.02.01.2001','081200000002','A','03','Amoxicillin (ruam kulit)'),
('RM-000003','3501012003100003',NULL,'Ahmad Fauzi','Siti Rohmah','L','Pacitan','2010-03-20','Jl. Melati No. 5, RT 01 / RW 03','35','35.01','35.01.01','35.01.01.2001','081200000003','B','02',NULL),
('RM-000004','3501015506950004','0009876543210','Dewi Lestari','Endang Sulastri','P','Kediri','1995-06-15','Jl. Kenanga No. 8, RT 04 / RW 02','35','35.71','35.71.01','35.71.01.1001','081200000004','AB','13','Debu / rinitis alergi'),
('RM-000005','3501011112550005','0005555555555','Sutrisno','Painem','L','Madiun','1955-12-11','Dsn. Sukorejo, RT 03 / RW 02','35','35.77','35.77.01','35.77.01.1001','081200000005','O','14',NULL),
('RM-000006','3501016004200006',NULL,'Aisyah Putri','Titin Suryani','P','Pacitan','2020-04-20','Jl. Anggrek No. 3, RT 02 / RW 01','35','35.01','35.01.01','35.01.01.2001','081200000006','-','01',NULL),
('RM-000007','3501017007880007','0007777777777','Rina Wulandari','Lastri Handayani','P','Nganjuk','1988-07-30','Jl. Dahlia No. 21, RT 05 / RW 02','35','35.18','35.18.01','35.18.01.2001','081200000007','A','08',NULL),
('RM-000008','3501010902700008',NULL,'Hendra Wijaya','Murtini','L','Surabaya','1970-02-09','Jl. Pahlawan No. 44, RT 01 / RW 04','35','35.78','35.78.01','35.78.01.1001','081200000008','B','08','Sulfa');
