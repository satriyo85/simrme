-- =====================================================================
-- Migrasi: Tambah ICD-9-CM (Tindakan / Prosedur)
-- Jalankan sekali pada database rme_belajar
-- =====================================================================

-- Tabel master ICD-9-CM
CREATE TABLE IF NOT EXISTS icd9cm (
  id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(10)  NOT NULL UNIQUE,
  nama VARCHAR(200) NOT NULL,
  INDEX idx_icd9_nama (nama)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel tindakan per pemeriksaan
CREATE TABLE IF NOT EXISTS pemeriksaan_tindakan (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pemeriksaan_id INT UNSIGNED NOT NULL,
  icd9_id        INT UNSIGNED NOT NULL,
  FOREIGN KEY (pemeriksaan_id) REFERENCES pemeriksaan(id) ON DELETE CASCADE,
  FOREIGN KEY (icd9_id)        REFERENCES icd9cm(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================================
-- Data sample ICD-9-CM (tindakan umum di fasilitas kesehatan primer)
-- =====================================================================
INSERT IGNORE INTO icd9cm (kode, nama) VALUES
-- Operasi / Tindakan Bedah Umum
('86.22', 'Debridement eksisi luka, infeksi, atau luka bakar'),
('86.59', 'Penjahitan kulit dan jaringan subkutan lainnya'),
('86.28', 'Insisi abses kulit dan jaringan lunak'),

-- Tindakan Diagnostik
('89.01', 'Wawancara, anamnesis, dan evaluasi klinis'),
('89.7',  'Elektrokardiogram (EKG)'),
('89.11', 'Pengukuran tekanan darah'),

-- Tindakan Terapeutik Umum
('93.18', 'Latihan / fisioterapi'),
('93.54', 'Pemasangan bidai / gips tanpa reduksi fraktur'),
('97.88', 'Pelepasan bidai ekstremitas bawah'),

-- Injeksi & Infus
('99.18', 'Injeksi obat / imunisasi lainnya'),
('99.21', 'Injeksi antibiotik'),
('99.25', 'Injeksi kortikosteroid'),
('99.29', 'Injeksi obat lainnya'),
('99.15', 'Transfusi darah lengkap'),

-- Tindakan Pernapasan
('93.94', 'Terapi oksigen'),
('93.90', 'Tindakan pernapasan lainnya'),

-- Tindakan Gastrointestinal
('96.35', 'Pemasangan selang nasogastrik (NGT)'),
('96.6',  'Irigasi lambung'),

-- Tindakan Urologi
('57.94', 'Pemasangan kateter urin (Foley)'),

-- Persalinan & Kebidanan
('72.1',  'Persalinan dengan forsep rendah'),
('73.59', 'Persalinan pervaginam lainnya'),
('74.1',  'Seksio sesarea klasik (SC)'),

-- Tindakan Mata / THT
('16.41', 'Irigasi mata / pembersihan benda asing'),
('22.00', 'Irigasi sinus nasal'),

-- Rehabilitasi & Edukasi
('93.82', 'Edukasi kesehatan / konseling pasien'),
('89.43', 'Pemeriksaan fisik umum / medical check-up');
