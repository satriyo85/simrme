-- =====================================================================
-- Pembaruan: Jadwal praktik dokter spesialis per poli
-- Jalankan HANYA jika database.sql versi lama sudah diimpor dan Anda
-- tidak ingin mengimpor ulang (data pasien/kunjungan tetap aman).
-- Jika belum punya data apa pun, cukup impor ulang database.sql terbaru.
-- =====================================================================
USE rme_belajar;

ALTER TABLE users ADD COLUMN spesialisasi VARCHAR(80) NULL AFTER role;
ALTER TABLE kunjungan
  ADD COLUMN dokter_id INT UNSIGNED NULL AFTER no_antrian,
  ADD COLUMN estimasi_jam TIME NULL AFTER dokter_id,
  ADD CONSTRAINT fk_kunj_dokter FOREIGN KEY (dokter_id) REFERENCES users(id),
  ADD INDEX idx_kunj_dokter (dokter_id, tgl_kunjungan);

CREATE TABLE jadwal_dokter (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  dokter_id INT UNSIGNED NOT NULL,
  poli_id INT UNSIGNED NOT NULL,
  hari TINYINT UNSIGNED NOT NULL,
  jam_mulai TIME NOT NULL,
  jam_selesai TIME NOT NULL,
  kuota SMALLINT UNSIGNED NOT NULL DEFAULT 20,
  menit_per_pasien SMALLINT UNSIGNED NOT NULL DEFAULT 15,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (dokter_id) REFERENCES users(id),
  FOREIGN KEY (poli_id) REFERENCES poli(id),
  UNIQUE KEY uq_jadwal (dokter_id, poli_id, hari, jam_mulai),
  INDEX idx_jadwal_hari (hari, poli_id)
) ENGINE=InnoDB;

-- Dokter lama (username 'dokter') menjadi dokter umum
UPDATE users SET spesialisasi = 'Dokter Umum', nama = 'dr. Andi Pratama' WHERE username = 'dokter';

-- Dokter spesialis baru (kata sandi: password123)
SET @h = (SELECT password FROM users WHERE username = 'admin');
INSERT INTO users (username, password, nama, role, spesialisasi) VALUES
('dokter.anak',  @h, 'dr. Bunga Lestari, Sp.A',     'dokter', 'Spesialis Anak (Sp.A)'),
('dokter.obgyn', @h, 'dr. Citra Maharani, Sp.OG',   'dokter', 'Spesialis Obstetri dan Ginekologi (Sp.OG)'),
('dokter.pd',    @h, 'dr. Dimas Wicaksono, Sp.PD',  'dokter', 'Spesialis Penyakit Dalam (Sp.PD)'),
('dokter.gigi',  @h, 'drg. Eka Putri',              'dokter', 'Dokter Gigi');

INSERT IGNORE INTO poli (kode, nama) VALUES ('AN', 'Poli Anak');

-- Jadwal contoh (dicari berdasarkan username/kode agar tidak bergantung pada nomor ID)
INSERT INTO jadwal_dokter (dokter_id, poli_id, hari, jam_mulai, jam_selesai, kuota, menit_per_pasien)
SELECT u.id, p.id, j.hari, j.mulai, j.selesai, j.kuota, j.menit
FROM (
  SELECT 'dokter' un,'UM' pk,1 hari,'08:00' mulai,'14:00' selesai,30 kuota,10 menit UNION ALL
  SELECT 'dokter','UM',2,'08:00','14:00',30,10 UNION ALL SELECT 'dokter','UM',3,'08:00','14:00',30,10 UNION ALL
  SELECT 'dokter','UM',4,'08:00','14:00',30,10 UNION ALL SELECT 'dokter','UM',5,'08:00','11:00',15,10 UNION ALL
  SELECT 'dokter','UM',6,'08:00','12:00',20,10 UNION ALL
  SELECT 'dokter.anak','AN',2,'09:00','13:00',16,15 UNION ALL SELECT 'dokter.anak','AN',4,'09:00','13:00',16,15 UNION ALL
  SELECT 'dokter.anak','AN',6,'09:00','12:00',12,15 UNION ALL
  SELECT 'dokter.obgyn','KI',1,'08:00','12:00',16,15 UNION ALL SELECT 'dokter.obgyn','KI',3,'08:00','12:00',16,15 UNION ALL
  SELECT 'dokter.obgyn','KI',5,'08:00','11:00',12,15 UNION ALL
  SELECT 'dokter.pd','LN',1,'09:00','13:00',16,15 UNION ALL SELECT 'dokter.pd','LN',2,'09:00','13:00',16,15 UNION ALL
  SELECT 'dokter.pd','LN',3,'09:00','13:00',16,15 UNION ALL SELECT 'dokter.pd','LN',4,'09:00','13:00',16,15 UNION ALL
  SELECT 'dokter.gigi','GI',1,'08:00','13:00',20,15 UNION ALL SELECT 'dokter.gigi','GI',2,'08:00','13:00',20,15 UNION ALL
  SELECT 'dokter.gigi','GI',3,'08:00','13:00',20,15 UNION ALL SELECT 'dokter.gigi','GI',4,'08:00','13:00',20,15 UNION ALL
  SELECT 'dokter.gigi','GI',5,'08:00','11:00',12,15
) j
JOIN users u ON u.username = j.un
JOIN poli p ON p.kode = j.pk;

-- Kunjungan lama (sebelum pembaruan) dibiarkan tanpa dokter; dokter mana pun boleh memeriksanya.
